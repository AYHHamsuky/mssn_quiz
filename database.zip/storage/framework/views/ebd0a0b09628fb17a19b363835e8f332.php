

<?php $__env->startSection('title', 'Create Quiz'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-900">Create New Quiz</h1>
    </div>

    <div class="bg-white shadow rounded-lg p-6">
        <form action="<?php echo e(route('admin.quizzes.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="space-y-6">
                <div>
                    <label for="title" class="block text-sm font-medium text-gray-700">Quiz Title</label>
                    <input type="text" name="title" id="title" required
                           class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                           value="<?php echo e(old('title')); ?>">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                    <textarea name="description" id="description" rows="3"
                              class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"><?php echo e(old('description')); ?></textarea>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="type" class="block text-sm font-medium text-gray-700">Quiz Type</label>
                        <select name="type" id="type" required
                                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <option value="">Select Type</option>
                            <option value="general" <?php echo e(old('type') == 'general' ? 'selected' : ''); ?>>General Subject</option>
                            <option value="debate" <?php echo e(old('type') == 'debate' ? 'selected' : ''); ?>>Debate</option>
                            <option value="impromptu_speech" <?php echo e(old('type') == 'impromptu_speech' ? 'selected' : ''); ?>>Impromptu Speech</option>
                            <option value="essay" <?php echo e(old('type') == 'essay' ? 'selected' : ''); ?>>Essay</option>
                            <option value="arabic_passage" <?php echo e(old('type') == 'arabic_passage' ? 'selected' : ''); ?>>Arabic Passage Reading</option>
                            <option value="english_passage" <?php echo e(old('type') == 'english_passage' ? 'selected' : ''); ?>>English Passage Reading</option>
                        </select>
                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="subject" class="block text-sm font-medium text-gray-700">Subject (Optional)</label>
                        <input type="text" name="subject" id="subject"
                               class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                               placeholder="e.g., Mathematics, English"
                               value="<?php echo e(old('subject')); ?>">
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                        <label for="duration_minutes" class="block text-sm font-medium text-gray-700">Duration (minutes)</label>
                        <input type="number" name="duration_minutes" id="duration_minutes" required min="1"
                               class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                               value="<?php echo e(old('duration_minutes', 30)); ?>">
                    </div>

                    <div>
                        <label for="question_timer" class="block text-sm font-medium text-gray-700">Time per Question (sec)</label>
                        <input type="number" name="question_timer" id="question_timer" required min="10" max="300"
                               class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                               value="<?php echo e(old('question_timer', 30)); ?>">
                    </div>

                    <div>
                        <label for="points_per_question" class="block text-sm font-medium text-gray-700">Points per Question</label>
                        <input type="number" name="points_per_question" id="points_per_question" required min="1"
                               class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                               value="<?php echo e(old('points_per_question', 2)); ?>">
                    </div>
                </div>

                <div class="flex justify-end space-x-3">
                    <a href="<?php echo e(route('admin.quizzes.index')); ?>" class="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Cancel
                    </a>
                    <button type="submit" class="bg-indigo-600 py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Create Quiz
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ITAPPS002\OneDrive\Documents\mssn_quiz\resources\views/admin/quizzes/create.blade.php ENDPATH**/ ?>