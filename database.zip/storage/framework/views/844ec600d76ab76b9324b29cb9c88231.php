<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'MSSN Quiz Application'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-50 antialiased">
    <?php if(auth()->guard()->check()): ?>
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex">
                    <div class="flex-shrink-0 flex items-center">
                        <h1 class="text-2xl font-bold text-indigo-600">MSSN Quiz</h1>
                    </div>
                    <div class="hidden sm:ml-6 sm:flex sm:space-x-8">
                        <?php if(Auth::user()->isAdmin()): ?>
                            <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php if(request()->routeIs('admin.dashboard')): ?> border-indigo-500 text-gray-900 <?php else: ?> border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 <?php endif; ?> inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                                Dashboard
                            </a>
                            <a href="<?php echo e(route('admin.quizzes.index')); ?>" class="<?php if(request()->routeIs('admin.quizzes.*')): ?> border-indigo-500 text-gray-900 <?php else: ?> border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 <?php endif; ?> inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                                Quizzes
                            </a>
                            <a href="<?php echo e(route('admin.leaderboard')); ?>" class="<?php if(request()->routeIs('admin.leaderboard')): ?> border-indigo-500 text-gray-900 <?php else: ?> border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 <?php endif; ?> inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                                Leaderboard
                            </a>
                            <a href="<?php echo e(route('admin.schools')); ?>" class="<?php if(request()->routeIs('admin.schools')): ?> border-indigo-500 text-gray-900 <?php else: ?> border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 <?php endif; ?> inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                                Schools
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('school.dashboard')); ?>" class="<?php if(request()->routeIs('school.dashboard')): ?> border-indigo-500 text-gray-900 <?php else: ?> border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 <?php endif; ?> inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                                Dashboard
                            </a>
                            <a href="<?php echo e(route('school.quizzes.index')); ?>" class="<?php if(request()->routeIs('school.quizzes.*')): ?> border-indigo-500 text-gray-900 <?php else: ?> border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 <?php endif; ?> inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                                Quizzes
                            </a>
                            <a href="<?php echo e(route('school.performance')); ?>" class="<?php if(request()->routeIs('school.performance')): ?> border-indigo-500 text-gray-900 <?php else: ?> border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 <?php endif; ?> inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                                Performance
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="flex items-center">
                    <span class="text-gray-700 mr-4"><?php echo e(Auth::user()->name); ?></span>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium">
                            Logout
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </nav>
    <?php endif; ?>

    <main class="<?php if(auth()->guard()->check()): ?> py-6 <?php endif; ?>">
        <?php if(session('success')): ?>
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-4">
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                </div>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-4">
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline"><?php echo e(session('error')); ?></span>
                </div>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>
</html>
<?php /**PATH C:\Users\ITAPPS002\OneDrive\Documents\mssn_quiz\resources\views/layouts/app.blade.php ENDPATH**/ ?>