@extends('layouts.app')

@section('title', 'Available Quizzes')

@section('content')
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-900">Available Quizzes</h1>
    </div>

    @if($liveQuizzes->count() > 0)
    <div class="mb-8">
        <h2 class="text-2xl font-semibold text-gray-900 mb-4">🔴 Live Quizzes</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @foreach($liveQuizzes as $quiz)
            <div class="bg-white border-2 border-green-500 shadow-lg rounded-lg overflow-hidden">
                <div class="p-6">
                    <div class="flex items-center justify-between mb-2">
                        <span class="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">LIVE NOW</span>
                        <span class="text-xs text-gray-500">{{ $quiz->questions->count() }} questions</span>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-2">{{ $quiz->title }}</h3>
                    <p class="text-sm text-gray-600 mb-1">{{ $quiz->getTypeLabel() }}</p>
                    @if($quiz->subject)
                    <p class="text-sm text-gray-500 mb-3">Subject: {{ $quiz->subject }}</p>
                    @endif
                    
                    <div class="mb-4 text-sm text-gray-600">
                        <p>⏱️ {{ $quiz->question_timer }} seconds per question</p>
                        <p>🎯 {{ $quiz->points_per_question }} points per correct answer</p>
                    </div>

                    @php
                        $participation = $quiz->participations->where('school_id', Auth::user()->school_id)->first();
                    @endphp

                    @if($participation)
                        @if($participation->status === 'completed')
                            <a href="{{ route('school.quizzes.results', $quiz) }}" class="block w-full bg-gray-600 hover:bg-gray-700 text-white text-center px-4 py-2 rounded-md">
                                View Results
                            </a>
                        @elseif($participation->status === 'in_progress')
                            <a href="{{ route('school.quizzes.participate', $quiz) }}" class="block w-full bg-orange-600 hover:bg-orange-700 text-white text-center px-4 py-2 rounded-md pulse">
                                Continue Quiz
                            </a>
                        @else
                            <a href="{{ route('school.quizzes.participate', $quiz) }}" class="block w-full bg-green-600 hover:bg-green-700 text-white text-center px-4 py-2 rounded-md pulse">
                                Start Quiz
                            </a>
                        @endif
                    @else
                        <form action="{{ route('school.quizzes.register', $quiz) }}" method="POST">
                            @csrf
                            <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md">
                                Register & Start
                            </button>
                        </form>
                    @endif
                </div>
            </div>
            @endforeach
        </div>
    </div>
    @endif

    @if($upcomingQuizzes->count() > 0)
    <div>
        <h2 class="text-2xl font-semibold text-gray-900 mb-4">📅 Upcoming Quizzes</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @foreach($upcomingQuizzes as $quiz)
            <div class="bg-white shadow rounded-lg overflow-hidden">
                <div class="p-6">
                    <div class="flex items-center justify-between mb-2">
                        <span class="px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">UPCOMING</span>
                        <span class="text-xs text-gray-500">{{ $quiz->questions->count() }} questions</span>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-2">{{ $quiz->title }}</h3>
                    <p class="text-sm text-gray-600 mb-1">{{ $quiz->getTypeLabel() }}</p>
                    @if($quiz->subject)
                    <p class="text-sm text-gray-500 mb-3">Subject: {{ $quiz->subject }}</p>
                    @endif
                    
                    <div class="mb-4 text-sm text-gray-600">
                        <p>📅 Starts: {{ $quiz->start_time->format('M d, Y H:i') }}</p>
                        <p>⏱️ {{ $quiz->question_timer }}s per question</p>
                        <p>🎯 {{ $quiz->points_per_question }} points each</p>
                    </div>

                    @php
                        $participation = $quiz->participations->where('school_id', Auth::user()->school_id)->first();
                    @endphp

                    @if($participation)
                        <button disabled class="w-full bg-gray-300 text-gray-600 px-4 py-2 rounded-md cursor-not-allowed">
                            Registered
                        </button>
                    @else
                        <form action="{{ route('school.quizzes.register', $quiz) }}" method="POST">
                            @csrf
                            <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md">
                                Register Now
                            </button>
                        </form>
                    @endif
                </div>
            </div>
            @endforeach
        </div>
    </div>
    @endif

    @if($liveQuizzes->count() === 0 && $upcomingQuizzes->count() === 0)
    <div class="text-center py-12">
        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
        </svg>
        <h3 class="mt-2 text-sm font-medium text-gray-900">No quizzes available</h3>
        <p class="mt-1 text-sm text-gray-500">Check back later for new quizzes.</p>
    </div>
    @endif
</div>

<style>
@keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
}
.pulse {
    animation: pulse 2s infinite;
}
</style>
@endsection
